/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include<stdio.h> //colocar la librearía de c 

#define tarifa_horaria 40 //definir constante

void main() //funcion principal del lenguaje c
{
    //declaración de variables
	float horas, salario_neto=0, salario_bruto,tasa_impuesto=0; //float para datos enteros o decimales
	char nombre[10]; //char para caracteres 
	printf("ingresar el nombre del trabajador:"); //print para mostrar en pantalla el nombre del trabajador
	scanf("%s",&nombre);
	/* ingresamos la cantidad de horas trabajadas*/
	printf("ingresar las horas trabajadas:");
	scanf("%f",&horas);
	if(horas<=35) /* determinar los salarios si las horas trabajadas son menos o igual a 35 horas*/
	{
		salario_bruto=horas*tarifa_horaria; /*calcular el salario bruto*/
		
		if(salario_bruto>1000 && salario_bruto<=1500) /*determinar los impuestos que se debe pagar dependiendo del salario bruto*/
		{
			/*determinar la tasa de impuestos cuando el salario bruto, es mayor a 1000 dolares y menor a 1500*/
			tasa_impuesto=salario_bruto*0.25;
			
			salario_neto=salario_bruto-tasa_impuesto; /* determinar el salario neto*/
			printf("el trabajador:%s\nel salario bruto es:%.2f\nla tasa de impuesto es:%.2f\nel salario neto es:%.2f",nombre,salario_bruto,tasa_impuesto,salario_neto);
		}
		else if(salario_bruto>1500)
		{
			tasa_impuesto=salario_bruto*0.45; /*determinar la tasa de impuestos cuando el salario bruto es mayor a 1500 dolares*/
			salario_neto=salario_bruto-tasa_impuesto;/* determinamos el salario neto*/
			printf("el trabajador:%s\nel salario bruto es:%.2f\nla tasa de impuesto es:%.2f\nel salario neto es:%.2f",nombre,salario_bruto,tasa_impuesto,salario_neto);
		}
		else
		{
			salario_neto=salario_bruto; /*determinar el salario neto si el salario bruto es menor a 1000 dolares*/
			printf("el trabajador:%s\nel salario bruto es:%.2f\nla tasa de impuesto es:%.2f\nel salario neto es:%.2f",nombre,salario_bruto,tasa_impuesto,salario_neto);
		}
	}
	else
	{
		
		salario_bruto=horas*tarifa_horaria*1.5; /*determinar el salario bruto si el trabajador trabaja mas de 35 horas*/
		if(salario_bruto>1000 && salario_bruto<=1500) /*determinar los impuestos a pagar dependiendo del salario bruto*/
		{
			tasa_impuesto=salario_bruto*0.25; /*determinar la tasa de impuestos cuando el salario bruto es mayor a 1000 dolares y menor a 1500*/
			salario_neto=salario_bruto-tasa_impuesto;
			printf("el trabajador:%s\nel salario bruto es:%.2f\nla tasa de impuesto es:%.2f\nel salario neto es:%.2f",nombre,salario_bruto,tasa_impuesto,salario_neto);
		}
		else if(salario_bruto>1500)
		{
			
			tasa_impuesto=salario_bruto*0.45; /*determinar la tasa de impuestos cuando el salario bruto es mayor a 1500 dolares*/
		
			salario_neto=salario_bruto-tasa_impuesto;	/* determinar el salario neto*/
			printf("el trabajador:%s\nel salario bruto es:%.2f\nla tasa de impuesto es:%.2f\nel salario neto es:%.2f",nombre,salario_bruto,tasa_impuesto,salario_neto);
		}
		else
		{
			/*determinar el salario neto si el salario bruto es menor a 1000 dolares*/
			salario_neto=salario_bruto;
			printf("el trabajador:%s\nel salario bruto es:%.2f\nla tasa de impuesto es:%.2f\nel salario neto es:%.2f",nombre,salario_bruto,tasa_impuesto,salario_neto);
		}
	}
}